function e = getEntropy(x)
    e = -x'*log(x);
end